import { cn } from "@/lib/utils";

type AppCardProps = {
  children: React.ReactNode;
  className?: string;
};

export function AppCard({
  children,
  className,
}: AppCardProps) {
  return (
    <section
      className={cn(
        [
          "rounded-3xl",
          "border border-slate-200",
          "bg-white",
          "p-6 md:p-8",
          "shadow-card",
          "transition-all",
          "duration-200",
          "hover:shadow-xl",
        ].join(" "),
        className,
      )}
    >
      {children}
    </section>
  );
}
