import { ReactNode } from "react";
import { AppShell } from "@/components/layout/AppShell";

export default function MasterLayout({
  children,
}: {
  children: ReactNode;
}) {
  return <AppShell>{children}</AppShell>;
}